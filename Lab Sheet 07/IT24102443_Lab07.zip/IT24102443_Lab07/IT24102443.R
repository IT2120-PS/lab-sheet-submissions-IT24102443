setwd("C:\\Users\\DELL\\Desktop\\IT24102443")
getwd()

#Question 1
#Unifrom Distribution
#X - number of minutes the train arrives after 8.00 a.m
#P(10<x<25) = p(x= 10) - p(x = 25)
punif(25, min = 0 , max = 40, lower.tail = TRUE) - punif(10, min = 0 , max = 40, lower.tail = TRUE)

#Question 2
#Exponential Distribution with lamda(rate) =  1 / 3
#p(x<=2)
pexp(2,rate = 1/3 , lower.tail = TRUE)

#Question 3
pnorm(130,mean = 100 , sd = 15 , lower.tail = FALSE)

qnorm(0.95 , mean = 100,sd =15)




